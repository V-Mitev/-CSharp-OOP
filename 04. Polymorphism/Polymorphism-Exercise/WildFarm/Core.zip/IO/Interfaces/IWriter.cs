﻿namespace WildFarm.IO.Interfaces
{
    public interface IWriter
    {
        void Write(string str);

        void WriteLine(string str);
    }
}