﻿namespace Raiding.Core.Interface
{
    public interface IEngine
    {
        void Run();
    }
}