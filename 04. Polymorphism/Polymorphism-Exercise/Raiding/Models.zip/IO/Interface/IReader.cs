﻿namespace Raiding.IO.Interface
{
    public interface IReader
    {
        string ReadLine();
    }
}