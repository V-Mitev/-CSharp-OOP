﻿namespace Raiding.IO.Interface
{
    public interface IWriter
    {
        void Write(string str);

        void WriteLine(string str);
    }
}